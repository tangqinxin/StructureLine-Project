/****************************************************************************
** Meta object code from reading C++ file 'camerawindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../camerawindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'camerawindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CameraWindow_t {
    QByteArrayData data[24];
    char stringdata0[676];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CameraWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CameraWindow_t qt_meta_stringdata_CameraWindow = {
    {
QT_MOC_LITERAL(0, 0, 12), // "CameraWindow"
QT_MOC_LITERAL(1, 13, 24), // "SignalInSub1_ShowMainWin"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 21), // "Signal_LUResToMainWin"
QT_MOC_LITERAL(4, 61, 14), // "vector<float>&"
QT_MOC_LITERAL(5, 76, 6), // "m_resx"
QT_MOC_LITERAL(6, 83, 6), // "m_resy"
QT_MOC_LITERAL(7, 90, 32), // "on_pushButton_ListDevice_clicked"
QT_MOC_LITERAL(8, 123, 29), // "on_pushButton_OpenCam_clicked"
QT_MOC_LITERAL(9, 153, 30), // "on_pushButton_CloseCam_clicked"
QT_MOC_LITERAL(10, 184, 31), // "on_pushButton_StartGrab_clicked"
QT_MOC_LITERAL(11, 216, 30), // "on_pushButton_StopGrab_clicked"
QT_MOC_LITERAL(12, 247, 28), // "on_pushButton_GetImg_clicked"
QT_MOC_LITERAL(13, 276, 31), // "on_pushButton_ParamsSet_clicked"
QT_MOC_LITERAL(14, 308, 30), // "on_pushButton_CalibCam_clicked"
QT_MOC_LITERAL(15, 339, 36), // "on_pushButton_ReadCalibParms_..."
QT_MOC_LITERAL(16, 376, 37), // "on_pushButton_ClearCalibParms..."
QT_MOC_LITERAL(17, 414, 30), // "on_pushButton_PlaneFit_clicked"
QT_MOC_LITERAL(18, 445, 33), // "on_pushButton_SetBaseLine_cli..."
QT_MOC_LITERAL(19, 479, 35), // "on_pushButton_ShowCurParams_c..."
QT_MOC_LITERAL(20, 515, 36), // "on_pushButton_MeasureSingleF_..."
QT_MOC_LITERAL(21, 552, 39), // "on_pushButton_MeasureContinuo..."
QT_MOC_LITERAL(22, 592, 39), // "on_pushButton_ShiftToMainWind..."
QT_MOC_LITERAL(23, 632, 43) // "on_pushButton_TestGetSingleIm..."

    },
    "CameraWindow\0SignalInSub1_ShowMainWin\0"
    "\0Signal_LUResToMainWin\0vector<float>&\0"
    "m_resx\0m_resy\0on_pushButton_ListDevice_clicked\0"
    "on_pushButton_OpenCam_clicked\0"
    "on_pushButton_CloseCam_clicked\0"
    "on_pushButton_StartGrab_clicked\0"
    "on_pushButton_StopGrab_clicked\0"
    "on_pushButton_GetImg_clicked\0"
    "on_pushButton_ParamsSet_clicked\0"
    "on_pushButton_CalibCam_clicked\0"
    "on_pushButton_ReadCalibParms_clicked\0"
    "on_pushButton_ClearCalibParms_clicked\0"
    "on_pushButton_PlaneFit_clicked\0"
    "on_pushButton_SetBaseLine_clicked\0"
    "on_pushButton_ShowCurParams_clicked\0"
    "on_pushButton_MeasureSingleF_clicked\0"
    "on_pushButton_MeasureContinuous_clicked\0"
    "on_pushButton_ShiftToMainWindow_clicked\0"
    "on_pushButton_TestGetSingleImg_Take_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CameraWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  109,    2, 0x06 /* Public */,
       3,    2,  110,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    0,  115,    2, 0x08 /* Private */,
       8,    0,  116,    2, 0x08 /* Private */,
       9,    0,  117,    2, 0x08 /* Private */,
      10,    0,  118,    2, 0x08 /* Private */,
      11,    0,  119,    2, 0x08 /* Private */,
      12,    0,  120,    2, 0x08 /* Private */,
      13,    0,  121,    2, 0x08 /* Private */,
      14,    0,  122,    2, 0x08 /* Private */,
      15,    0,  123,    2, 0x08 /* Private */,
      16,    0,  124,    2, 0x08 /* Private */,
      17,    0,  125,    2, 0x08 /* Private */,
      18,    0,  126,    2, 0x08 /* Private */,
      19,    0,  127,    2, 0x08 /* Private */,
      20,    0,  128,    2, 0x08 /* Private */,
      21,    0,  129,    2, 0x08 /* Private */,
      22,    0,  130,    2, 0x08 /* Private */,
      23,    0,  131,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4, 0x80000000 | 4,    5,    6,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void CameraWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CameraWindow *_t = static_cast<CameraWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->SignalInSub1_ShowMainWin(); break;
        case 1: _t->Signal_LUResToMainWin((*reinterpret_cast< vector<float>(*)>(_a[1])),(*reinterpret_cast< vector<float>(*)>(_a[2]))); break;
        case 2: _t->on_pushButton_ListDevice_clicked(); break;
        case 3: _t->on_pushButton_OpenCam_clicked(); break;
        case 4: _t->on_pushButton_CloseCam_clicked(); break;
        case 5: _t->on_pushButton_StartGrab_clicked(); break;
        case 6: _t->on_pushButton_StopGrab_clicked(); break;
        case 7: _t->on_pushButton_GetImg_clicked(); break;
        case 8: _t->on_pushButton_ParamsSet_clicked(); break;
        case 9: _t->on_pushButton_CalibCam_clicked(); break;
        case 10: _t->on_pushButton_ReadCalibParms_clicked(); break;
        case 11: _t->on_pushButton_ClearCalibParms_clicked(); break;
        case 12: _t->on_pushButton_PlaneFit_clicked(); break;
        case 13: _t->on_pushButton_SetBaseLine_clicked(); break;
        case 14: _t->on_pushButton_ShowCurParams_clicked(); break;
        case 15: _t->on_pushButton_MeasureSingleF_clicked(); break;
        case 16: _t->on_pushButton_MeasureContinuous_clicked(); break;
        case 17: _t->on_pushButton_ShiftToMainWindow_clicked(); break;
        case 18: _t->on_pushButton_TestGetSingleImg_Take_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (CameraWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CameraWindow::SignalInSub1_ShowMainWin)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (CameraWindow::*_t)(vector<float> & , vector<float> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CameraWindow::Signal_LUResToMainWin)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject CameraWindow::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_CameraWindow.data,
      qt_meta_data_CameraWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *CameraWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CameraWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CameraWindow.stringdata0))
        return static_cast<void*>(const_cast< CameraWindow*>(this));
    return QWidget::qt_metacast(_clname);
}

int CameraWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 19;
    }
    return _id;
}

// SIGNAL 0
void CameraWindow::SignalInSub1_ShowMainWin()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void CameraWindow::Signal_LUResToMainWin(vector<float> & _t1, vector<float> & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
